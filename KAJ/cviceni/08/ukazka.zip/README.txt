vyrob adresa uploads na stejne urovni jako je soubor file.php
